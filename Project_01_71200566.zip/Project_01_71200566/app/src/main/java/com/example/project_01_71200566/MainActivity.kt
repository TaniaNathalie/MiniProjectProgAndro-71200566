package com.example.project_01_71200566

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rdGroup1 = findViewById<RadioGroup>(R.id.rdGroup1)
        val rdYogyakarta = findViewById<RadioButton>(R.id.rdYogyakarta)
        val rdJakarta = findViewById<RadioButton>(R.id.rdJakarta)
        val rdBali = findViewById<RadioButton>(R.id.rdBali)
        val rdGroup2 = findViewById<RadioGroup>(R.id.rdGroup2)
        val rdYogyakarta2 = findViewById<RadioButton>(R.id.rdYogyakarta2)
        val rdJakarta2 = findViewById<RadioButton>(R.id.rdJakarta2)
        val rdBali2 = findViewById<RadioButton>(R.id.rdBali2)
        val edtTanggal = findViewById<EditText>(R.id.edtTanggal)
        val btnPesan = findViewById<Button>(R.id.btnPesan)

        btnPesan.setOnClickListener {
            val intent = Intent(this, KeduaActivity::class.java)

            if(rdGroup1.checkedRadioButtonId == -1){
                intent.putExtra("asalKota", rdYogyakarta.text.toString())
            }
            else if(rdGroup1.checkedRadioButtonId == rdJakarta.id){
                intent.putExtra("asalKota", rdJakarta.text.toString())
            }
            else{
                intent.putExtra("asalKota", rdBali.text.toString())
            }

            if(rdGroup2.checkedRadioButtonId == -1){
                intent.putExtra("tujuanKeberangkatan", rdYogyakarta2.text.toString())
            }
            else if(rdGroup2.checkedRadioButtonId == rdJakarta2.id){
                intent.putExtra("tujuanKeberangkatan", rdJakarta2.text.toString())
            }
            else{
                intent.putExtra("tujuanKeberangkatan", rdBali2.text.toString())
            }
            intent.putExtra("tanggal", edtTanggal.text.toString())
            startActivity(intent)
        }

    }
}