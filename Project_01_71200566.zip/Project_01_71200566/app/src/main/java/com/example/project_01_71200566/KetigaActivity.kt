package com.example.project_01_71200566

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class KetigaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tiga)


        val asalKota = intent.getStringExtra("asalKota")
        val tujuanKeberangkatan = intent.getStringExtra("tujuanKeberangkatan")
        val tanggal = intent.getStringExtra("tanggal")
        val jamKeberangkatan = intent.getStringExtra("jamKeberangkatan")
        val kelasTiket = intent.getStringExtra("kelasTiket")

        val txtHasil = findViewById<TextView>(R.id.txvHasil)
        txtHasil.text = "Asal Kota: ${asalKota} \nTujuan Keberangkatan: ${tujuanKeberangkatan} \nTanggal: ${tanggal} \nJam Keberangkatan: ${jamKeberangkatan} \nKelas Tiket: ${kelasTiket}"
    }
}