package com.example.project_01_71200566

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class KeduaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dua)

        val asalKota = intent.getStringExtra("asalKota")
        val tujuanKeberangkatan = intent.getStringExtra("tujuanKeberangkatan")
        val tanggal =  intent.getStringExtra("tanggal")


        val rdGroup3 = findViewById<RadioGroup>(R.id.rdGroup3)
        val rdSatu = findViewById<RadioButton>(R.id.rdSatu)
        val rdDua = findViewById<RadioButton>(R.id.rdDua)
        val rdTiga = findViewById<RadioButton>(R.id.rdTiga)
        val rdGroup4 = findViewById<RadioGroup>(R.id.rdGroup4)
        val rdEmpat = findViewById<RadioButton>(R.id.rdEmpat)
        val rdLima = findViewById<RadioButton>(R.id.rdLima)
        val btnPesan2 = findViewById<Button>(R.id.btnPesan2)


        btnPesan2.setOnClickListener {
            val intent = Intent(this, KetigaActivity::class.java)
            if(rdGroup3.checkedRadioButtonId == -1){
                intent.putExtra("jamKeberangkatan", rdSatu.text.toString())
            }
            else if(rdGroup3.checkedRadioButtonId == rdDua.id){
                intent.putExtra("jamKeberangkatan", rdDua.text.toString())
            }
            else{
                intent.putExtra("jamKeberangkatan", rdTiga.text.toString())
            }

            if(rdGroup4.checkedRadioButtonId == -1){
                intent.putExtra("kelasTiket", rdEmpat.text.toString())
            }
            else{
                intent.putExtra("kelasTiket", rdLima.text.toString())
            }
            intent.putExtra("asalKota", asalKota.toString())
            intent.putExtra("tujuanKeberangkatan", tujuanKeberangkatan.toString())
            intent.putExtra("tanggal", tanggal.toString())
            startActivity(intent)
        }
    }
}
